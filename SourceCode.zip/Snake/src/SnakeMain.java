public class SnakeMain {
    public static void main(String[] args) {

        new GameFrame();
    }
}
